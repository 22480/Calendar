import React from 'react'

export default function VacationItems(props) {
  return (
    <div>
        <select name={} id={}>
            
        </select>
    </div>
  )
}
