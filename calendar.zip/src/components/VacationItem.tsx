import React from 'react'

export default function VacationItem() {
  return (
    <div>VacationItem</div>
  )
}
