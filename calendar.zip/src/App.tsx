import { useState } from "react"
import styles from "./styles/styles.module.css"

function App() {
    const [vacation,getVacation] = useState("假期")
    
    return (
        <div>
            <div className={styles.container}>  
                <select name="dropdownVacation" id="dropdown">
                    <option value="option1">Option1</option>
                    <option value="option2">Option2</option>
                    <option value="option3">Option3</option>
                </select>
                <select name="dropdownYear" id="dropdown">
                    <option value="option1">Option1</option>
                    <option value="option2">Option2</option>
                    <option value="option3">Option3</option>
                </select>
                <select name="dropdownMonth" id="dropdown">
                    <option value="option1">Option1</option>
                    <option value="option2">Option2</option>
                    <option value="option3">Option3</option>
                </select>
                <button>今天</button>
            </div>
            <div className={styles.content}>
                <div className={styles.contentContainer}></div>
                <div className={styles.contentDate}></div>
            </div>
        </div>
    )
}

export default App
