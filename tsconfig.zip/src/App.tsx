import { useEffect, useState } from "react"
import styles from "./styles/styles.module.css"
import Checkbox, { XtCheckBox } from "./components/Checkbox"
import Container from "./components/Container"
// import moment from 'moment';
// import 'moment-lunar';
import { vacationList, yearList, monthList } from "../src/components/ContainerData.tsx"

function App() {
    const [selectedVacation, setSelectedVacation] = useState("元旦节")
    const [selectedYear, setSelectedYear] = useState("2024")
    const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1)

    const currentDate = new Date()

    // function getLunarDate(year, month, day) {
    //     const currentDate = moment({ year, month, day })
    //     const lunarDate = currentDate.lunar();
    //     const lunarDay = lunarDate.date()
    //     return lunarDay
    //   }
    function generateCalendarData(year, month) {
        console.log(year, month)
        const calendarData = []
        const firstDayOfMonth = new Date(+year, +month - 1, 1)
        // console.log(firstDayOfMonth)
        const lastDayOfMonth = new Date(+year, +month, 0)
        // console.log(lastDayOfMonth)
        const daysInMonth = lastDayOfMonth.getDate()
        // console.log(daysInMonth)
        const firstDayOfWeek = firstDayOfMonth.getDay() - 1
        // console.log(firstDayOfWeek)
        let currentDate = 1
        Array.from({ length: 6 }).map((_, i) => {
            calendarData[i] = []
            // console.log(i)
            Array.from({ length: 7 }).map((_, j) => {
                if (i === 0 && j < firstDayOfWeek) {
                    const prevMonthLastDate = new Date(year, month - 1, 0).getDate()
                    // console.log(prevMonthLastDate)
                    calendarData[i][j] =
                        //prevMonthLastDate - firstDayOfWeek + j + 1
                        {
                            date: prevMonthLastDate - firstDayOfWeek + j + 1,
                            isSaturday: false,
                            isSunday: false,
                            isHoliday: false
                            // showLunarData:getLunarDate(year, month, prevMonthLastDate - firstDayOfWeek + j + 1)
                        }
                } else if (currentDate > daysInMonth) {
                    calendarData[i][j] =
                        //currentDate - daysInMonth
                        //currentDate++
                        {
                            date: currentDate - daysInMonth,
                            isSaturday: false,
                            isSunday: false,
                            isHoliday: false
                            // showLunarData:getLunarDate(year, month, currentDate - daysInMonth)
                        }
                    currentDate++
                } else {
                    calendarData[i][j] =
                        //currentDate
                        {
                            date: currentDate,
                            isSaturday: false,
                            isSunday: false,
                            isHoliday: false
                            // showLunarData:getLunarDate(year, month, currentDate)
                        }
                    currentDate++
                }
                if (j === 5 && i % 2 === 0) {
                    calendarData[i][j].isSaturday = true
                    // console.log(calendarData[i][j])
                }
                if (j === 6) {
                    calendarData[i][j].isSunday = true
                }
            })
        })
        // console.log(calendarData)
        return calendarData.map((items, index) => {
            return (
                <tbody key={`b${index}`}>
                    <tr key={`a${index}`}>
                        {items.map((item, index) => {
                            const sunday = item.isSunday ? "sunday" : ""
                            const saturday = item.isSaturday ? "saturday" : ""
                            const holiday = item.isHoliday ? "holiday" : ""
                            const className = `${styles.containerLi} ${styles[`${sunday}`]} ${styles[`${saturday}`]} ${styles[`${holiday}`]}`
                            return (
                                <th key={`c${index}`} className={className}>
                                    {item.date}
                                </th>
                            )
                        })}
                    </tr>
                </tbody>
            )
        })
    }

    const [cat, setCat] = useState("布偶猫")

    useEffect(() => {
        console.log(cat)
    }, [cat])

    const [fruit, setFruit] = useState("苹果")

    return (
        <div className={styles.calendar}>
            <XtCheckBox options={[{ name: "布偶猫" }, { name: "银渐层" }]} value={cat} onChange={e => setCat(e)}></XtCheckBox>
            <XtCheckBox options={[{ name: "苹果" }, { name: "梨子" }]} value={fruit} onChange={e => setFruit(e)}></XtCheckBox>
            <div className={styles.container}>
                <Checkbox list={vacationList} generateCalendarData={generateCalendarData} selectedVacation={selectedVacation} selectedYear={selectedYear} selectedMonth={selectedMonth} setSelectedVacation={setSelectedVacation} setSelectedYear={setSelectedYear} setSelectedMonth={setSelectedMonth} />
                <Checkbox list={yearList} generateCalendarData={generateCalendarData} selectedVacation={selectedVacation} selectedYear={selectedYear} selectedMonth={selectedMonth} setSelectedVacation={setSelectedVacation} setSelectedYear={setSelectedYear} setSelectedMonth={setSelectedMonth} />
                <Checkbox list={monthList} generateCalendarData={generateCalendarData} selectedVacation={selectedVacation} selectedYear={selectedYear} selectedMonth={selectedMonth} setSelectedVacation={setSelectedVacation} setSelectedYear={setSelectedYear} setSelectedMonth={setSelectedMonth} />
                <button>今天</button>
            </div>
            <div className={styles.content}>
                <div className={styles.contentContainer}>
                    <Container selectedMonth={selectedMonth} selectedYear={selectedYear} currentDate={currentDate} generateCalendarData={generateCalendarData} />
                </div>
                <div className={styles.contentDate}></div>
            </div>
        </div>
    )
}

export default App
