import React from "react"
import container from "../styles/container.module.css"

export default function Container({ selectedMonth, currentDate ,selectedYear,generateCalendarData}) {
    // const month = selectedMonth !== undefined ? selectedMonth : currentDate.getMonth() + 1
    // const year = selectedMonth !== undefined ? currentDate.getFullYear() : currentDate.getFullYear()
    // function generateCalendarData(year, month) {
    //     const calendarData = []
    //     const firstDayOfMonth = new Date(year, month - 1, 1)
    //     const lastDayOfMonth = new Date(year, month, 0)
    //     const daysInMonth = lastDayOfMonth.getDate()
    //     const firstDayOfWeek = firstDayOfMonth.getDay()
    //     let currentDate = 1
    //     for (let i = 0; i < 6; i++) {
    //         calendarData[i] = []
    //         for (let j = 0; j < 7; j++) {
    //             if (i === 0 && j < firstDayOfWeek) {
    //                 // 如果是第一周，并且在本月开始之前
    //                 const prevMonthLastDate = new Date(year, month - 1, 0).getDate()
    //                 calendarData[i][j] = prevMonthLastDate - firstDayOfWeek + j + 1
    //             } else if (currentDate > daysInMonth) {
    //                 calendarData[i][j] = currentDate - daysInMonth
    //                 currentDate++
    //             } else {
    //                 calendarData[i][j] = currentDate
    //                 currentDate++
    //             }
    //         }
    //     }
    //     return calendarData.map(items => {
    //         return (
    //             <tbody>
    //             <tr key={`${year}-${items}`}>
    //                 {items.map(item => {
    //                     return (
    //                         <th key={`${month}-${item}`} className={container.containerLi}>
    //                             {item}
    //                         </th>
    //                     )
    //                 })}
    //             </tr>
    //             </tbody>
    //         )
    //     })
    // }
    
    return (
        <div className={container.all}>
            <table className={container.tableAll}>
            <thead >
                <tr key="container" className={container.container}>
                    <th  className={container.containerLi}>
                        一
                    </th>
                    <th  className={container.containerLi}>
                        二
                    </th>
                    <th  className={container.containerLi}>
                        三
                    </th>
                    <th  className={container.containerLi}>
                        四
                    </th>
                    <th  className={container.containerLi}>
                        五
                    </th>
                    <th  className={container.containerLi}>
                        六
                    </th>
                    <th  className={container.containerLi}>
                        日
                    </th>
                </tr>
                </thead>
                {generateCalendarData(selectedYear,selectedMonth )}
            </table>
        </div>
    )
}
