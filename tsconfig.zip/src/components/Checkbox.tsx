import React, { FC } from "react"
import box from "../styles/box.module.css"
import CheckItem from "./CheckItem"
type XtCheckBoxProps = {
    options: { name: string }[]
    value: null | string
    onChange: (data: string) => void
}
export const XtCheckBox: FC<XtCheckBoxProps> = props => {
    const { options, value, onChange } = props
    return (
        <select value={value} onChange={e => onChange(e.target.value)}>
            <CheckItem list={options} />
        </select>
    )
}

// value和onChange事件
export default function Checkbox({ list, generateCalendarData, selectedMonth, selectedVacation, selectedYear, setSelectedVacation, setSelectedYear, setSelectedMonth }) {
    function handleSelected(e: React.ChangeEvent<HTMLSelectElement>) {
        // const chooseItem = e.target.options[e.target.selectedIndex]
        const selectName = e.target.name
        // console.log("select的name值:", selectName)
        const selectedOptions = Array.from(e.target.selectedOptions).map(option => option.value)
        // console.log(selectedOptions)
        if (selectName === "vacation") {
            setSelectedVacation(selectedOptions)

            const nowYear = selectedYear
            console.log(nowYear)
            const nowMonth = selectedMonth
            console.log(nowMonth)
            generateCalendarData(nowYear, nowMonth)
        } else if (selectName === "year") {
            const useYear = parseInt(selectedOptions[0])
            setSelectedYear(useYear)
            const nowMonth = selectedMonth
            generateCalendarData(useYear, nowMonth)
        } else {
            const clickMonth = parseInt(e.target.value.replace("月", ""))
            setSelectedMonth(clickMonth)
        }
    }
    const selectedValue = list[0].type === "vacation" ? selectedVacation : list[0].type === "year" ? selectedYear : selectedMonth + "月"
    // console.log(selectedValue)
    return (
        <select name={list[0].type} value={selectedValue} className={box.dropdown} onChange={handleSelected}>
            <CheckItem list={list} />
        </select>
    )
}
